import React , {useState} from 'react';
import Header from './Header';
import './LoginPage.css';
import image from './download2.png';
import axios from 'axios';
import './App.css';

import { useNavigate } from 'react-router-dom';

const Login = () => {
    const navigate = useNavigate();
    const [selectedOption, setSelectedOption] = useState('');
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
  
    const handleLogin = () => {
      // Implement your login logic based on the selectedOption (hod or student)
      // For example, you can make an API call to authenticate the user
  
      if (selectedOption === 'hod') {
        // Handle HOD login
        // After successful login, redirect to the HOD profile page
        axios.get(`http://localhost:4000/getHodById/${username}`)
          .then((response) => {
            const hodDetails = response.data;
            navigate({
              pathname: `/getHodById/${username}`,
              state: { details: hodDetails }
            });
          })
          .catch((error) => {
            console.error('Error fetching HOD details:', error);
          });
      } else if (selectedOption === 'student') {
        // Handle Hostel Student login
        // After successful login, redirect to the Hostel Student profile page
        axios.get(`http://localhost:4000/hostelstudent/${username}`)
          .then((response) => {
            const studentDetails = response.data;
            navigate({
              pathname: `/hostelstudent/${username}`,
              state: { details: studentDetails }
            });
          })
          .catch((error) => {
            console.error('Error fetching student details:', error);
          });
      }
    };
  
    return (
      <div >
          <Header />
          <div className="App">

        <h1>Login Page</h1>
        <label>Select User Type:</label>
        <select onChange={(e) => setSelectedOption(e.target.value)}>
          <option value="">Select...</option>
          <option value="hod">HOD</option>
          <option value="student">Hostel Student</option>
        </select>
        <br></br>
        <br></br>
        <label>Username:</label>
        <input
          type="text"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />
        <br></br>
        <label>Password:</label>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <br></br>
        <button onClick={handleLogin}>Login</button>
      </div>
      </div>
     
    );
  };
  
  export default Login;

