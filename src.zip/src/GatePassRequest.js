import React, { useState, useEffect } from 'react'; 
import axios from 'axios';
import LoginPage from './LoginPage';
import { useParams, Link } from 'react-router-dom';


const GatePassRequest = () => {
    const { request_id } = useParams();
    <GatePassRequest request_id={request_id}/>
    const { student_id } = useParams(); 
       console.log(student_id) ;    

     
        <LoginPage student_id={student_id}/>
    
  
  const [requests, setRequests] = useState([]);
  

  useEffect(() => {
    console.log("request not found");
    // Fetch gate pass requests for the student using Axios
    axios.get(`http://localhost:4000/getGatePassRequestById/${request_id}`)
      .then((response) => {
        setRequests(response.data);
      })
      .catch((error) => {
        console.error('Error fetching requests:', error);
      });
  }, [request_id]);

  return (
    <div>
      <h1>Gate Pass Requests</h1>
      <p>Student ID: {student_id}</p>
      {requests && (
        <table>
          <thead>
            <tr>
              <th>Request ID</th>
              <th>Reason</th>
              <th>Destination</th>
              {/* Add more table headers as needed */}
            </tr>
          </thead>
          <tbody>
            {requests.map((request) => (
              <tr key={request.request_id}>
                <td>{request.reason_name}</td>
                <td>{request.destination}</td>
                {/* Add more table data (td) as needed */}
              </tr>
            ))}
          </tbody>
        </table>
      ) }
    </div>
  );
};

export default GatePassRequest;

