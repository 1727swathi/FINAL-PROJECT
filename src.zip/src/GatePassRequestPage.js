import React, { useState } from 'react'; 
import axios from 'axios';
import LoginPage from './LoginPage';
import './GatePassRequestPage.css';
import { useParams, Link } from 'react-router-dom';
import Header from './Header' // Import the CSS module

const GatePassRequestPage = () => {
  const { student_id } = useParams();
  <LoginPage student_id={student_id}/>
  
  const [formData, setFormData] = useState({
    request_date: '',
    return_date: '',
    destination: '',
    request_time: '',
    student_id: student_id,
    reason_date: '',
    status: 'pending'
    
  });
  const [successMessage, setSuccessMessage] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Send a POST request to your API to submit the gate pass request
    axios.post('http://localhost:4000/student', formData)
      .then(() => {
        // Handle success
        setSuccessMessage('Gate pass request submitted successfully');
      })
      .catch((error) => {
        // Handle errors
        console.error('Error submitting request:', error);
        setSuccessMessage('Error submitting the request. Please try again later.');
      });
    
    // Reset the form after submission
    setFormData({
      request_date: '',
      return_Date: '',
      destination: '',
      request_time: '',
      student_id: student_id,
      reason_name:'',
      status:'pending'
    });
  };

  return (
    <div className="container">
      <Header />
      <h1>Gate Pass Request</h1>
      <form className="form" onSubmit={handleSubmit}>
      <p>Student ID: {student_id}</p>
        <div>
          <label className="label" htmlFor="date"> Return Date:</label>
          <input
            type="date"
            id="return_date"
            name="return_date"
            value={formData.return_date}
            onChange={handleChange}
            className="inputField"
          />
        </div>
        <div>
          <label className="label" htmlFor="date"> Request Date:</label>
          <input
            type="date"
            id="request_date"
            name="request_date"
            value={formData.request_date}
            onChange={handleChange}
            className="inputField"
          />
        </div>
        <div>
          <label className="label" htmlFor="date">Request time</label>
          <input
            type="text"
            id="request_time"
            name="request_time"
            value={formData.request_time}
            onChange={handleChange}
            className="inputField"
          />
        </div>
        <div>
          <label className="label" htmlFor="date">Destination</label>
          <input
            type="text"
            id="destination"
            name="destination"
            value={formData.destination}
            onChange={handleChange}
            className="inputField"
          />
        </div>
        <div>
          <label className="label" htmlFor="date">Reason Name:</label>
          <input
            type="text"
            id="reason_name"
            name="reason_name"
            value={formData.reason_name}
            onChange={handleChange}
            className="inputField"
          />
        </div>
      
        {/* Repeat the same pattern for other form fields */}
        <button type="submit" className="submitButton">Submit Request</button>
      </form>
      {successMessage && <p className="successMessage">{successMessage}</p>}
      <Link to={`/hostelstudent/${student_id}`}>
    <button className="submitbutton">Back</button>

  </Link>
  <Link to={`/getGatePassRequestById/${student_id}`}>
    <button className="submitbutton">Dashboard</button>

  </Link>
    </div>
    

  );
};


    
  
 
export default GatePassRequestPage;
