import React, { useState } from 'react';

import Header from './Header';

// import './ForgetPasswordPage.css';
import {Link } from 'react-router-dom';


 

 

 

function ForgotPasswordPage() {

 

    const [Email, setEmail] = useState('');

 

    const handleChangePasword = (event) =>{

        event.preventDefault();

 

    };

    return (

        <div>

            <Header />

            <div className="change-password-container">

                <div className="title">

                <h1>Forgot Password</h1>

                

                </div>

                <form onSubmit={handleChangePasword} >

                    <input

                        type="text"

                        placeholder=""

                        value={Email}

                        onChage={(e) => setEmail(e.target.value)}

                        className="backupEmail"

                    />

                    <br />

                    <button type="submit" className="submitButton">send password reset mail</button>

                </form>
                <Link to={`/`}>
          <button>Back</button>

        </Link>

 

            </div>

        </div>

    );

}

export default ForgotPasswordPage;