import React from 'react'; 
import { useParams, Link } from 'react-router-dom';
import axios from 'axios';
import { useState,useEffect } from 'react';



import './Profile.css';
import LoginPage from './LoginPage';


const HodProfile = () => {
       const { username} = useParams(); 
       console.log(username) ;    

     
        <LoginPage username={username}/>
      
        
        const [student, setStudent] = useState(null);
        console.log(student);
      
      
        useEffect(() => {
          console.log("hi");
          axios.get(`http://localhost:4000/getHodById/${username}`)
            .then(response => {
              console.log("reached");
              console.log("Response",response)
              setStudent(response.data);
            })
            .catch(error => {
              console.log("hi");
              // Handle errors (e.g., student not found)
              console.error(error);
            });
        }, [username]);
      
  return (
      <div>
    <header className="header">
     
      <nav>
      <h1>HOSTEL GATE PASS MANAGEMENT</h1>
        
      </nav>
      </header>
      <div className="student-id">
          <br></br>
        {student && 
        (
        <div>
          <p>HOD ID: {username}</p>
           <p>Name: {student.name}</p>
          <p>Contact: {student.contact}</p>
          <p>department: {student.department}</p>
          
          
        </div> 
        )} 
        
        <Link to="/">
          <button>Back to login</button>

        </Link>

     
        

      </div>
      </div>
   
  );
};


export default HodProfile;