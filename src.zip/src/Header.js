

import './LoginPage.css';

function Header(){
    return(
        <h1 className="header-image">HOSTEL GATE PASS MANAGEMENT</h1>
    );
}

export default Header;