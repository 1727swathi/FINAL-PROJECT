
import './App.css';
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import LoginPage from './LoginPage';
import ForgetPassword from './ForgetPasswordPage';
import Profile from './Profile';
import GatePassRequestPage from './GatePassRequestPage';
import GatePassRequest from './GatePassRequest';
import HodProfile from './HodProfile';




function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<LoginPage/> } />
        <Route path="/hostelstudent/:username" element={<Profile />}/>
        <Route path="/student/:student_id" element={<GatePassRequestPage />}/>
        <Route path="/getGatePassRequestById/:student_id" element={<GatePassRequest />}/>
        <Route path="/forgetpasswordpage" element={<ForgetPassword/>}/>
        <Route path="/getHodById/:username" element={<HodProfile/>}/>

        
       
      </Routes>
    </Router>
    
    
    
  );
}

export default App;
